import React, { Component } from 'react';
import { Link } from "react-router-dom";
import 'office-ui-fabric-react/dist/css/fabric.css';
import { initializeIcons } from '@uifabric/icons';
import { connect } from "react-redux";
import { Card, Table, ButtonToolbar, Overlay, Popover, Button, ListGroup, ListGroupItem, Modal } from 'react-bootstrap';
import { CategoriesFetch, RemoveCategoryByID, fetchCategoryByID, CategoryFetchBegin } from '../../Actions/CategoryActions';
import './UpsertCategory.sass';
import { TextField, Dropdown, Checkbox, Label } from 'office-ui-fabric-react';
import { isTypeParameter } from '@babel/types';
initializeIcons();
class UpsertCategory extends Component<any, any>
{
    constructor(props: any) {
        super(props);
        this.state = { NewCategory: { name: "", description: "", mandatory: false, Attributes: [{ display: true, mandatory: false }] }, RowCount: 1 }
        this.props.CategoryID && this.props.dispatch(fetchCategoryByID(this.props.CategoryID));
    }
    // componentDidMount() {
    //     debugger;
    //     //this.setState({ Attributes: [this.props.Category.attributes] });

    // }
    save() {
        // alert("save" + this.state.NewCategory);
        console.log(this.state.NewCategory);
        this.props.UpsertCategoryStatus(false);
    }
    addAttribute() {
        this.setState({ RowCount: this.state.RowCount + 1, NewCategory: { ...this.state.NewCategory, Attributes: [...this.state.NewCategory.Attributes, { display: true, mandatory: false }] } });

    }
    DeleteRow(id: number) {
        let items: any = this.state.NewCategory;
        items.Attributes[id] = false;
        this.setState({ NewCategory: items });
    }

    handleChange(e: any) {
        // debugger;
        let newCategory = this.state.NewCategory;
        newCategory[e.target.name] = e.target.value
        this.setState({ NewCategory: newCategory });
    }

    handleAttributeChange(index: number, e: any) {
        let newCategory = this.state.NewCategory;
        let attribute = newCategory.Attributes[index];
        attribute[e.target.name] = e.target.value;
        // debugger;
        this.setState({ NewCategory: newCategory });

    }
    render() {
        return (
            <div>
                <Modal className="UpsertCategory" show={true} onHide={() => this.props.UpsertCategoryStatus(false)}>
                    <Modal.Header closeButton>
                        <Modal.Title>View & Edit :{this.props.CategoryID ? this.props.Category.name : this.state.NewCategory.name}</Modal.Title>
                    </Modal.Header>
                    <Modal.Title className="Description">
                        Add new category to the Classifieds
                            <Button variant="primary" onClick={this.save.bind(this)}>
                            save
                            </Button>
                    </Modal.Title>
                    <Modal.Body>
                        <div className="Form">
                            <div className="CategoryName">
                                <TextField label="Category Name" name="name" value={this.props.CategoryID ? this.props.Category.name : this.state.NewCategory.name} onChange={this.handleChange.bind(this)} />
                            </div>
                            <div className="CategoryIcon">
                                {/* <Dropdown
                                    placeholder="Select"
                                    label="Icon"
                                    multiSelect={false}
                                    options={[{ key: 'a', text: 'vehicle' }, { key: 'a', text: 'vehicle' }, { key: 'a', text: 'vehicle' }]}
                                    styles={{ dropdown: { width: 100 } }}
                                    onChange={this.handleChange.bind(this)}
                                /> */}
                                <Label>Icon</Label>
                                <select className="Icons">
                                    <option>Text</option>
                                    <option>Number</option>
                                    <option>checkbox</option>

                                </select>

                            </div>
                        </div>
                        <div className="CategoryDescription">
                            <TextField label="Standard" name="description" multiline rows={3} value={this.props.CategoryID ? this.props.Category.description : this.state.NewCategory.description} onChange={this.handleChange.bind(this)} />
                        </div>
                        <div className="Attributes">
                            <h1>Attributes of the Category</h1>
                            <p>Attributes of an asset such as price,location,description etc</p>
                            <Table striped bordered hover>
                                <thead>
                                    <tr>
                                        <td>Field Name</td>
                                        <td className="Type">Field Type</td>
                                        <td>Values</td>
                                        <td>Mark as Mandatory</td>
                                        <td>Action</td>
                                    </tr>
                                </thead>
                                <tbody>

                                    {
                                        this.props.CategoryID ?
                                            this.props.Category.id && this.props.Category.attributes.map((item: any, index: number) =>
                                                // item &&
                                                <tr>
                                                    <td>
                                                        <TextField value={item.name} />
                                                    </td>
                                                    <td>
                                                        {/* <Dropdown
                                                            placeholder="Select options"
                                                            multiSelect={false}
                                                            selectedKey={[item.type.trim()]}
                                                            options={[{ key: 'Text', text: 'Text' }, { key: 'Number', text: 'Number' }, { key: 'CheckBox', text: 'CheckBox' }]}
                                                            styles={{ dropdown: { width: 150 } }}
                                                        /> */}
                                                        <select className="Type">
                                                            <option>Text</option>
                                                            <option>Number</option>
                                                            <option>CheckBox</option>
                                                        </select>
                                                    </td>
                                                    <td>
                                                        Not applicable
                                        </td>
                                                    <td>
                                                        <Checkbox styles={{ root: { width: 150 } }} defaultChecked={item.mandatory} />
                                                    </td>
                                                    <td>
                                                        <i className="far fa-trash-alt" onClick={this.DeleteRow.bind(this, index)}></i>
                                                    </td>
                                                </tr>
                                            )
                                            :
                                            this.state.NewCategory.Attributes.map((item: any, index: number) =>
                                                item.display &&
                                                <tr>
                                                    <td>
                                                        <TextField name="Attributename" onChange={this.handleAttributeChange.bind(this, index)} value={this.state.NewCategory.Attributes[index].name} />
                                                    </td>
                                                    <td>
                                                        {/* <Dropdown
                                                            placeholder="Select options"
                                                            multiSelect={false}
                                                            selectedKey={['Text']}
                                                            options={[{ key: 'Text', text: 'Text' }, { key: 'Number', text: 'Number' }, { key: 'CheckBox', text: 'CheckBox' }]}
                                                            styles={{ dropdown: { width: 150 } }} onChange={this.handleAttributeChange.bind(this, index)}
                                                        /> */}
                                                        <select className="Type">
                                                            <option>Text</option>
                                                            <option>Number</option>
                                                            <option>CheckBox</option>
                                                        </select>
                                                    </td>
                                                    <td>
                                                        Not applicable
                                                </td>
                                                    <td>
                                                        <Checkbox name="mandatory" styles={{ root: { width: 150 } }} onChange={this.handleAttributeChange.bind(this, index)} />
                                                    </td>
                                                    <td>
                                                        <i className="far fa-trash-alt" onClick={this.DeleteRow.bind(this, index)}></i>
                                                    </td>
                                                </tr>
                                            )

                                    }


                                </tbody>
                            </Table>
                            <div className="AddAttribute" onClick={this.addAttribute.bind(this)}>
                                +Add Attribute
                            </div>
                        </div>
                    </Modal.Body>

                </Modal>
            </div>

        );
    }
}
function mapStateToProps(state: any) {
    return {
        Category: state.CategoriesReducer.Category,
    }
}
export default connect(mapStateToProps)(UpsertCategory);













