import React, { Component } from 'react';
class MakeAnOffer extends Component {
    constructor(props:any) {
        super(props);
        this.state = {  };
    }
    render() {
        return (
            <div className="MakeAnOfferMainDiv">
                <div className="MakeAnOfferInnerDiv">
                    
                </div>
            </div>
        );
    }
}

export default MakeAnOffer;