import { CATEGORY_FETCH_SUCCESS, CATEGORY_FETCH_ERROR, CATEGORY_FETCH_BEGIN, CATEGORIES_FETCH_BEGIN, CATEGORIES_FETCH_ERROR, CATEGORIES_FETCH_SUCCESS } from "../Actions/CategoryActions";

const initialstate = {
    Categories: [],
    CategoriesError: false,
    CategoriesFetchErrorInfo: "",
    Category:[],
    CategoryError:false,
    CategoryFetchErrorInfo:"",
    // Attributes: []
}

export default function CategoriesReducer(state = initialstate, action: any) {
    switch (action.type) {
        case CATEGORIES_FETCH_BEGIN:
            return {
                ...state,
                Categories: []
            }
        case CATEGORIES_FETCH_SUCCESS:
            return {
                ...state,
                Categories: action.payload.Categories
            }
        case CATEGORIES_FETCH_ERROR:
            return {
                ...state,
                CategoriesError: true,
                CategoriesFetchErrorInfo: action.payload.error
            }

        case CATEGORY_FETCH_BEGIN:
            debugger;
            return{
                ...state,
                Category:[],
                Attributes:[],
                CategoryError:false
            }

        case CATEGORY_FETCH_SUCCESS:
            return {
                ...state,
                Category: action.payload.Category,
                Attributes:action.payload.Category.attributes
            }

        case CATEGORY_FETCH_ERROR:
            return {
                ...state,
                CategoryError: true,
                CategoryFetchErrorInfo: action.payload.error
            }
        default:
            return {
                ...state
            }
    }
}