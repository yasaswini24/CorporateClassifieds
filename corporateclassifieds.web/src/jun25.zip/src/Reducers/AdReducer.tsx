import { FETCH_ADS_BEGIN, FETCH_ADS_SUCCESS, FETCH_ADS_ERROR, POST_AD_ERROR, APPLY_FILTERS, FETCH_ACTIVE_ADS_BEGIN, FETCH_ACTIVE_ADS_SUCCESS, FETCH_ACTIVE_ADS_ERROR, FETCH_HISTORY_ADS_BEGIN, FETCH_HISTORY_ADS_SUCCESS, FETCH_HISTORY_ADS_ERROR } from "../Actions/AdActions";

const intialstate = {
    Ads: [],
    FilteredAds: [],
    ActiveAds: [],
    HistoryAds: [],
    error: false,
    loading: true,
    adPostError: false,
    AdsAvailable: false,
    ActiveAdsAvailable: false,
    HistoryAdsAvailable: false,
    errorInfo: ""
};



// function handlefilter(AdsList: any, filtersList: any): boolean {
//     var filteredAds: any = [];
//     AdsList.forEach((item: any) => {
//         (filtersList.AdType).forEach((Type: any) => {
//             if (item.Type == Type)
//                 filteredAds.push(item)
//         })

//     });

//     AdsList.forEach((item: any) => {
//         (filtersList.AdType).forEach((Type: any) => {
//             if (item.Type == Type)
//                 filteredAds.push(item)
//         })

//     });
//     return true;
// }




export default function AdReducer(state = intialstate, action: any) {
    switch (action.type) {

        case FETCH_ADS_BEGIN:
            console.log("Ads Fetch begin");
            return {
                ...state,
                loading: true,
                error: false,

            }

        case FETCH_ADS_SUCCESS:
            console.log("Ads Fetch success")
            debugger;

            if (action.payload.Ads.length == 0)
                return {
                    ...state,
                    loading: false,
                    Ads: state.Ads,
                    AdsAvailable: false,
                    error: false
                }
            else {
                return {
                    ...state,
                    loading: false,
                    Ads: [...state.Ads, ...action.payload.Ads],
                    AdsAvailable: true,
                    error: false
                }
            }





        case FETCH_ADS_ERROR:
            console.log("Ads Fetch error")
            return {
                ...state,
                loading: false,
                errorInfo: action.payload.error,
                error: true,
                Ads: [],
                AdsAvailable: false
            }


        case POST_AD_ERROR:
            return {
                ...state,
                adPostError: true
            }



        case FETCH_ACTIVE_ADS_BEGIN:
            console.log("active ads fetch begin");
            return {
                ...state,
                loading: true,
                error: false
            }


        case FETCH_ACTIVE_ADS_SUCCESS:
            console.log("active ads fetch success");
            if (action.payload.ActiveAds.length == 0) {
                if (state.ActiveAds.length) {
                    debugger;
                    return {
                        ...state,
                        loading: false,
                        ActiveAdsAvailable: true,
                        error: false
                    }
                }
                else {
                    debugger;
                    return {
                        ...state,
                        loading: false,
                        ActiveAdsAvailable: false,
                        error: false
                    }
                }
            }
            else {
                debugger;
                return {
                    ...state,
                    loading: false,
                    ActiveAds: [...state.ActiveAds, ...action.payload.ActiveAds],
                    ActiveAdsAvailable: true,
                    error: false
                }
            }

        case FETCH_ACTIVE_ADS_ERROR:
            console.log("active ads fetch error");
            return {
                ...state,
                loading: false,
                error: true,
                errorInfo: action.payload.error
            }




        case FETCH_HISTORY_ADS_BEGIN:
            console.log("History ads fetch begin");
            return {
                ...state,
                loading: true,
                error: false
            }


        case FETCH_HISTORY_ADS_SUCCESS:
            console.log("History ads fetch success");
            if (action.payload.HistoryAds.length == 0) {
                if (state.HistoryAds.length) {
                    return {
                        ...state,
                        loading: false,
                        HistoryAdsAvailable: true,
                        error: false
                    }
                }
                else {
                    return {
                        ...state,
                        loading: false,
                        HistoryAdsAvailable: false,
                        error: false
                    }
                }
            }
            else {
                return {
                    ...state,
                    loading: false,
                    HistoryAds: [...state.HistoryAds, ...action.payload.HistoryAds],
                    HistoryAdsAvailable: true,
                    error: false
                }
            }

        case FETCH_HISTORY_ADS_ERROR:
            console.log("History ads fetch error");
            return {
                ...state,
                loading: false,
                error: true,
                errorInfo: action.payload.error
            }

        default:
            return state;
    }
}