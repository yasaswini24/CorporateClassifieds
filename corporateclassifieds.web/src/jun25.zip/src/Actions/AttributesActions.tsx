
export function AttributeFetchSuccess(Attributes: any) {
    return {
        type: 'AttributeFetchSuccess',
        payload: {Attributes}
    }
}

export function AttributeFetchError(error:any){
    return{
        type:'AttributeFetchError',
        payload:{error}
    }
}

export function AttributesFetch(id:number){
    return async (dispatch:any)=>{
        debugger;
        try{
            const url="https://localhost:44378/api/Category/"+id;
            const response=await fetch(url);
            const res = await handleErrors(response);
            const Category=await res.json();
            dispatch(AttributeFetchSuccess(Category.attributes));
        }
        catch (error) {
            return dispatch(AttributeFetchError(error));
          }
    }
}

function handleErrors(response: any) {
    if (!response.ok) {
      throw Error(response.statusText);
    }
    return response;
  }