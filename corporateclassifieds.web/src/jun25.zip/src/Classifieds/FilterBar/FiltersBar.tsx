import React, { Component } from 'react';
import { Link } from 'react-router-dom';
import 'office-ui-fabric-react/dist/css/fabric.css';
import { Dropdown } from 'office-ui-fabric-react/lib/Dropdown';
import { initializeIcons } from 'office-ui-fabric-react/lib/Icons';
import { SearchBox } from 'office-ui-fabric-react/lib/SearchBox';
import { DefaultButton } from 'office-ui-fabric-react';
import { undo } from 'react-icons-kit/fa/undo'
import Icon from 'react-icons-kit';
import { list2 } from 'react-icons-kit/icomoon/list2'
import { ic_apps } from 'react-icons-kit/md/ic_apps';
import "./FiltersBar.sass";
import { connect } from 'react-redux';
import { applyFilters } from '../../Actions/AdActions';
initializeIcons();



class FiltersBar extends Component<any, any>
{
  constructor(props: any) {
    super(props);
    this.state = {
      selectedItems: {
        AdType: [], Category: [], Posted: [], Location: []
      }
    }
  }

  // Filter(e: any) {
  //   debugger;
  //   this.setState({selectedItems:{[e.target.id]}});
  // }

  private Filter = (e: any, item: any): void => {
    debugger;
    const AdType = [...this.state.selectedItems.AdType];
    const Category = [...this.state.selectedItems.Category];
    const Posted = [...this.state.selectedItems.Posted];
    const Location = [...this.state.selectedItems.Location];
    if (e.target.id == "Dropdown1") {
      if (item.selected) {
        AdType.push(item.text as string);
      }
      else {
        const currIndex = AdType.indexOf(item.text as string);
        if (currIndex > -1) {
          AdType.splice(currIndex, 1);
        }
      }
    }

    else if (e.target.id == "Dropdown2") {

      if (item.selected) {
        Category.push(item.text as string);
      }
      else {
        const currIndex = Category.indexOf(item.text as string);
        if (currIndex > -1) {
          Category.splice(currIndex, 1);
        }
      }
    }

    else if (e.target.id == "Dropdown3") {

      if (item.selected) {
        Posted.push(item.text as string);
      }
      else {
        const currIndex = Posted.indexOf(item.text as string);
        if (currIndex > -1) {
          Posted.splice(currIndex, 1);
        }
      }
    }

    else {

      if (item.selected) {
        Location.push(item.text as string);
      }
      else {
        const currIndex = Location.indexOf(item.text as string);
        if (currIndex > -1) {
          Location.splice(currIndex, 1);
        }
      }
    }
    const FiltersList = { AdType: AdType, Category: Category, Posted: Posted, Location: Location };
    this.setState({
      selectedItems: FiltersList
    });
    console.log(FiltersList);
    this.props.dispatch(applyFilters(FiltersList));
  };


  render() {
    var Categories: any = []
    debugger;
    console.log(this.state);
    return (
      <div className="ms-Grid List FiltersBar" dir="ltr">
        <div className="ms-Grid-row">

          <div className="ms-Grid FiltersBar" dir="ltr">
            <div className="ms-Grid-col ms-sm7 DropDownFilters">
              <div className="ms-Grid-col ms-sm2 AdTypeDropDown">
                <Dropdown
                  className="testing"
                  placeholder="Ad Type"
                  onChange={this.Filter.bind(this)}
                  multiSelect
                  options={[
                    { key: 'sale', text: 'For Sale' },
                    { key: 'rent', text: 'For Rent' }
                  ]}


                />
              </div>
              <div className="ms-Grid-col ms-sm3 CategoryDropDown">
                {
                  this.props.Categories.map((item: any) => {
                    debugger;
                    Categories.push({ text: item.name })
                  }
                  )

                }
                <Dropdown
                  placeholder="Category"
                  options={Categories}
                  onChange={this.Filter.bind(this)}
                  multiSelect
                />
              </div>
              <div className="ms-Grid-col ms-sm3 PostedDropDown">
                <Dropdown
                  placeholder="Posted"
                  multiSelect
                  onChange={this.Filter.bind(this)}
                  options={[
                    { key: 'vehicle', text: 'Vehicle' },
                    { key: 'property', text: 'Property' }
                  ]}
                />
              </div>
              <div className="ms-Grid-col ms-sm4 LocationDropDown">
                <Dropdown
                  placeholder="Location"
                  multiSelect
                  onChange={this.Filter.bind(this)}
                  options={[
                    { key: 'vehicle', text: 'Vehicle' },
                    { key: 'property', text: 'Property' }
                  ]}
                />
              </div>

            </div>
            <div className="ms-Grid-col ms-sm5 Search">
              <div className="ms-Grid-col ms-sm8 SearchBar">
                <SearchBox />
              </div>
              <div className="ms-Grid-col ms-sm2 Reset">
                <DefaultButton className="ResetButton">
                  <Icon size={20} icon={undo} />
                  <label>Reset</label>
                </DefaultButton>
              </div>

              <div className="ms-Grid-col ms-sm1 GridViewOption">
                <Link to={this.props.GridViewPath}>
                  <DefaultButton>
                    <Icon size={30} icon={ic_apps} />
                  </DefaultButton>
                </Link>
              </div>


              <div className="ms-Grid-col ms-sm1 ListViewOption" >
                <Link to={this.props.ListViewPath}>
                  <DefaultButton>
                    <Icon size={20} icon={list2} />
                  </DefaultButton>
                </Link>
              </div>

            </div></div>
        </div>
      </div>

    );

  }


}

function mapStateToProps(state: any) {
  return {
    Categories: state.CategoriesReducer.Categories
  }
}
export default connect(mapStateToProps)(FiltersBar);