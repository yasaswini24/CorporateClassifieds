import React from 'react'
import { Component } from 'react'
import { connect } from 'react-redux';
import 'office-ui-fabric-react/dist/css/fabric.css';
import FiltersBar from '../../FilterBar/FiltersBar';
import "./ListView.sass";
import AdList from './AdList';
import { fetchAds } from '../../../Actions/AdActions';


class ListView extends Component<any, any>{

componentDidMount(){
  
}
scrolled=(scroll:any)=>{
  debugger;
      if (scroll.target.scrollTop + scroll.target.clientHeight+100 >=scroll.target.scrollHeight) {
        this.props.dispatch(fetchAds(this.props.Ads.length));
        // alert("scrolled");
      }
}
  render() {
    if (this.props.loading) {
      return <div>loading</div>
    }


    return (
      <div className="ListItemGrid" >
        {/* <FiltersBar GridViewPath="/Classifieds/SaleRent/GridView" ListViewPath="/Classifieds/SaleRent/ListView" /> */}
        <div className="ms-Grid List ListItemHeader" dir="ltr">
          <div className="ms-Grid-row">
            <div className="ms-Grid-col ms-sm5">

              <div className="ms-Grid-col ms-sm3  block">
                ITEM OR SELL
                    </div>

              <div className="ms-Grid-col ms-sm10">
                <div className="ms-Grid-row">

                </div>
                <div className="ms-Grid-row block3">

                </div>
              </div>

            </div>

            <div className="ms-Grid-col ms-sm7">

              <div className="ms-Grid-col ms-sm2 block">PRICE</div>

              <div className="ms-Grid-col ms-sm3 block">
                <div className="ms-Grid-row name">POSTED  BY</div>
              </div>

              <div className="ms-Grid-col ms-sm3 block">EXPIRES ON</div>

              <div className="ms-Grid-col ms-sm2  block">OFFER COUNT</div>

              <div className="ms-Grid-col ms-sm2 block ">COMMENT COUNT</div>

            </div>


          </div>

        </div>
        <div className="Scrolltest" onScroll={this.scrolled.bind(this)}>
          {this.props.AdListItem.map((item: any) =>

            <AdList key={item.id} item={item} />
          )}
        </div>
      </div>


    );
  }
}
function mapStateToProps(state: any) {
  debugger;
  return {
    error: state.AdReducer.error,
    loading: state.AdReducer.loading,
    Ads: state.AdReducer.Ads
  }
}

export default connect(mapStateToProps, undefined)(ListView);