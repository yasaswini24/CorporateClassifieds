import React, { Component } from 'react';
import { BrowserRouter as Router, Route, Redirect } from "react-router-dom";
import 'office-ui-fabric-react/dist/css/fabric.css';
import { initializeIcons } from '@uifabric/icons';
import { connect } from "react-redux";
import './../SaleRent/SaleRent.sass';
import ListView from "./ListView/ListView";
import GridView from "./GridView/Gridview";
import FiltersBar from '../FilterBar/FiltersBar';


initializeIcons();
class SaleRent extends Component<any, any>
{
    render() {
        return (
            <div>
                <Router>
                    <main className="content-wrapper">
                        <div className="header">
                            <h1>For Sale/Rent</h1>
                            <p>Here you can manage categories.</p>
                        </div>

                        <div  className="SaleRent">
                            <FiltersBar GridViewPath="/Classifieds/SaleRent/GridView" ListViewPath="/Classifieds/SaleRent/ListView" />
                            {/* <Route exact path="/Classifieds/SaleRent" component={ListView}/> */}
                            <Route exact path="/Classifieds/SaleRent/ListView" component={()=><ListView AdListItem={this.props.Ads}/>} />
                            <Route exact path="/Classifieds/SaleRent/GridView" component={()=><GridView AdGridItem={this.props.Ads}/>} />
                            <Redirect to="/Classifieds/SaleRent/ListView" />
                        </div>


                    </main>
                </Router>
            </div>

        );
    }
}
function mapStateToProps(state: any) {
    return {
        user: state.user,
        Ads:state.AdReducer.Ads
    }
}
export default connect(mapStateToProps)(SaleRent);













