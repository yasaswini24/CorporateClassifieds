import React, { Component } from 'react';
import { Link, Route } from "react-router-dom";
import 'office-ui-fabric-react/dist/css/fabric.css';
import { initializeIcons } from '@uifabric/icons';
import { connect } from "react-redux";
import FiltersBar from '../../Classifieds/FilterBar/FiltersBar';
import Gridview from '../../Classifieds/SaleRent/GridView/Gridview';
import ListView from '../../Classifieds/SaleRent/ListView/ListView';
import ActiveClassifiedsImage  from "../activeclassifieds1.png";
import './History.sass';
import { fetchUserAds } from '../../Actions/AdActions';


// import './../SaleRent/SaleRent.sass'

initializeIcons();
class History extends Component<any, any>
{
    componentDidMount() {
        this.props.dispatch(fetchUserAds(2,2,this.props.HistoryAds.length));    /////////user id need to be given in the first field  when authentication is added
    }
    render() {
        return (
            <div className="DescriptionBar">

                <main className="content-wrapper">
                    <div className="header">
                        <h1>History</h1>
                        <p>here you can manage the way you capture things</p>

                        <div className="cta-button-panel">
                            <Link to="/MyClassifieds/CreateAd">
                                <div className="btn btn-primary">
                                    Create Ad
                                </div>
                            </Link>
                        </div>
                    </div>
                    <div className="History">
                        <FiltersBar GridViewPath="/MyClassifieds/History/GridView" ListViewPath="/MyClassifieds/History" />
                        {
                            this.props.ClassifiedsHistoryAvailable ?
                                <div>
                                    <Route exact path="/MyClassifieds/History/GridView" component={()=><Gridview AdGridItem={this.props.HistoryAds} AdStatusDisplay={true}/>} />
                                    <Route exact path="/MyClassifieds/History" component={()=><ListView AdListItem={this.props.HistoryAds}/>} />
                                </div>
                                : <img className="ActiveClassifiedsImage" src={ActiveClassifiedsImage} alt="ActiveClassifiedsImage" />
                        }
                    </div>
                </main>
            </div>

        );
    }
}
function mapStateToProps(state: any) {
    debugger;
    return {
        loading: state.AdReducer.loading,
        HistoryAds: state.AdReducer.HistoryAds,
        ClassifiedsHistoryAvailable: state.AdReducer.HistoryAdsAvailable
    }
}
export default connect(mapStateToProps)(History);













