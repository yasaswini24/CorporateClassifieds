import React from 'react';
import { Dropdown } from 'office-ui-fabric-react/lib/Dropdown';
import { Icon } from 'react-icons-kit';
import { TextField } from 'office-ui-fabric-react/lib/TextField';
import 'office-ui-fabric-react/dist/css/fabric.css';
import { initializeIcons } from "office-ui-fabric-react/lib/Icons";
import { DefaultButton, Label } from 'office-ui-fabric-react';
import './PostAdd.sass';
import './Imageslide.css';
import Personinfo from './Personinfo';
import { ic_arrow_back } from 'react-icons-kit/md/ic_arrow_back';
import Dropzone from 'react-dropzone';
import { connect } from 'react-redux';
import Card from 'react-bootstrap/Card';
import { postAd } from '../../Actions/AdActions';
import { CategoriesFetch } from '../../Actions/CategoryActions';
import { AttributesFetch } from '../../Actions/AttributesActions';


initializeIcons();
const imageMaxSize = 10000000 // bytes
const acceptedFileTypes = 'image/x-png, image/png, image/jpg, image/jpeg, image/gif'
const acceptedFileTypesArray = acceptedFileTypes.split(",").map((item) => { return item.trim() })
var sortedImgFiles = new Array();
var imgToBeUploaded = new Array();

class PostAdd extends React.Component<any, any>
{
    constructor(props: any) {
        super(props);
        this.state = {
            imgToBeUploaded: null,
            imgsrc: imgToBeUploaded[0],
            StartIndex: 0, Type: "", CategoryDetails: { id: 1 }, Price: 0, Name: "", Description: "", CreatedByUser: { id: 1 }, ModifiedByUser: { id: 1 }, Status: { id: 1 }, Expiry: 0, Images: []

        };

    }
    componentDidMount() {
        debugger;
        this.props.dispatch(CategoriesFetch());
    }


    submit() {

        let Ad = this.state;
debugger;
        console.log(JSON.stringify(Ad));
        this.props.dispatch(postAd(JSON.stringify(Ad)));
        this.setState({ Type: "", CategoryDetails: { id: 1 }, Price: 0, Name: "", Description: "", CreatedByUser: { id: 1 }, ModifiedByUser: { id: 1 }, Status: { id: 1 }, Expiry: 0 });
        debugger;
        // const url = "https://localhost:44378/api/Ad";
        // fetch(url, {
        //     method: 'post',
        //     headers: new Headers({ 'content-type': 'application/json' }),
        //     body: JSON.stringify(Ad)
        // }).then(function (response) {
        //     console.log("success");
        // });



    }
    change(e: any) {
        this.setState(
            {
                [e.target.name]: e.target.value

            }
        );
    }

    getAttributes(e: any) {
        debugger;
        var categoryID = e.target.options[e.target.selectedIndex].id;
        this.setState({ CategoryDetails: { id: categoryID } });
        this.props.dispatch(AttributesFetch(categoryID));
    }




    Add() {

    }
    DisplayImage(details: any) {

        this.setState(
            this.state = { imgsrc: details }
        );
        console.log(this.state);
    }
    DeleteImage = (details: any) => {
        let index = imgToBeUploaded.indexOf(details)
        this.setState({
            imgToBeUploaded: imgToBeUploaded.splice(index, 1),
        })
        console.log(imgToBeUploaded)

    }

    verifyFile = (files: any) => {
        if (files && files.length > 0) {

            files.map((item: any) => {
                const currentFile = item
                const currentFileType = currentFile.type
                const currentFileSize = currentFile.size
                if (currentFileSize > imageMaxSize) {
                    alert("This file is not allowed. " + currentFileSize + " bytes is too large")
                    return false
                }
                if (!acceptedFileTypesArray.includes(currentFileType)) {
                    alert("This file is not allowed. Only images are allowed.")
                    return false
                }
                else {
                    sortedImgFiles.push(item);
                    return true
                }
            })

            return true;
        }
    }
    handleOnDrop = (files: any, rejectedFiles: any) => {
        if (rejectedFiles && rejectedFiles.length > 0) {
            this.verifyFile(rejectedFiles)
        }

        if (files && files.length > 0) {
            const isVerified = this.verifyFile(files)
            if (isVerified === true) {
                // imageBase64Data 
                files.map((item: any) => {
                    let currentFile: any = item
                    let myFileItemReader = new FileReader()
                    myFileItemReader.addEventListener("load", () => {
                        // console.log(myFileItemReader.result)
                        const myResult = myFileItemReader.result
                        this.setState({
                            imgToBeUploaded: imgToBeUploaded.push(myResult),
                            imgsrc: imgToBeUploaded[0]
                        })

                    }, false)
                    myFileItemReader.readAsDataURL(currentFile)
                })

            }
        }
    }

    render() {
        return (
            <div className="ms-Grid-row">
                <div className="ms-Grid-row">
                    <div className="ms-Grid-col ms-lg12 PostAdBackToList">
                        <h4> <Icon icon={ic_arrow_back} size={32} className="BackArrow" /> Back to List</h4>
                    </div>
                </div>
                {/* Left side*/}
                <div className="ms-Grid-col ms-lg8 ItemDetailsMainCol">

                    <div className="ms-Grid-row adDetails">
                        <div className="ms-Grid-row ItemDetailsMainRow">
                            <div className="ms-Grid-row">
                                <div className="ms-Grid-col ms-sm4">
                                    <h3>Item Details</h3>
                                </div>
                            </div>

                            <div className="ms-Grid-row">

                                <div className="ms-Grid-col ms-sm4">
                                    <Dropdown onChange={this.change.bind(this)}
                                        placeholder="Select"
                                        label="Ad Type"
                                        ariaLabel="Custom dropdown example"
                                        className="PostAdDropDown"

                                        options={[
                                            { key: 'A', text: 'For Sale', data: { icon: 'Memo' } },
                                            { key: 'B', text: 'For Rent', data: { icon: 'Print' } },
                                            { key: 'C', text: 'Required', data: { icon: 'ShoppingCart' } },

                                        ]}
                                    />
                                </div>

                                <div className="ms-Grid-col ms-sm4">
                                    <select className="ms-Dropdown-select" name="CategoryDetails" onChange={this.getAttributes.bind(this)}>
                                        <option key="0">--select--</option>
                                        {
                                            this.props.AdListItem.map((category: any) =>
                                                <option key={category.id} id={category.id} >{category.name}</option>
                                            )
                                        }

                                    </select>
                                </div>

                                <div className="ms-Grid-col ms-sm4 ">
                                    <TextField label="Prize" className='PostAdTitle' prefix='$' />
                                </div>

                            </div>


                            <div>
                                {
                                    <TextField label={"item.name"} className='PostAdTitle' />
                                }
                                {
                                    <TextField label={"item.name"} multiline rows={4} className='PostAdDesc' value="Provide Item Details" />
                                }
                                {
                                    <TextField label={"item.name"} className='PostAdTitle' prefix='$' />
                                }
                                {
                                    this.props.AttributeItem.map((Attribute: any) =>
                                        <tr>
                                            <tr>
                                                <td><label>{Attribute.name}</label></td>
                                            </tr>
                                            <tr className="Field">
                                                <input key={Attribute.ID} type={Attribute.type.toLowerCase().trim()} name={Attribute.name} onChange={this.change.bind(this)} />
                                            </tr>
                                        </tr>
                                    )
                                }
                            </div>
                            )}
                        </div>
                    </div>

                    <div className="ms-Grid-row">

                        {sortedImgFiles.length === 0 &&
                            <div className="ms-Grid-col ms-sm12 DragDropCol" >
                                <Dropzone onDrop={this.handleOnDrop} accept={acceptedFileTypesArray} maxSize={imageMaxSize}>
                                    {({ getRootProps, getInputProps }) => (
                                        <section>
                                            <div {...getRootProps()}>
                                                <input {...getInputProps()} />
                                                <div className="ms-Grid-row PostAdImage">
                                                    <div className="ms-Grid-row pos">
                                                        <div className="ms-Grid-col ms-sm12  border">
                                                            {/* <img src={require('./images.png')} width={128} height={128} alt="ad" /> */}
                                                            <div>
                                                                <DefaultButton text="+Add images" allowDisabledFocus={true} onClick={this.Add.bind(this)} />
                                                                <Label>(optional)</Label>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                        </section>
                                    )}
                                </Dropzone>
                                <div className="ms-Grid-row PostAdImageCarsol">
                                    <div className="ms-Grid-col ms-sm12">
                                        <div className="Carasol text-muted">
                                            <h3>No images added...</h3>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        }
                        {sortedImgFiles.length > 0 &&
                            <div className="ms-Grid-col ms-sm12 DragDropCol" >
                                <Dropzone onDrop={this.handleOnDrop} accept={acceptedFileTypesArray} maxSize={imageMaxSize}>
                                    {({ getRootProps, getInputProps }) => (
                                        <section>
                                            <div {...getRootProps()}>
                                                <input {...getInputProps()} />
                                                <div className="ms-Grid-row PostAdImage">
                                                    <Card>
                                                        <div className='ProdImgView'>
                                                            <img src={this.state.imgsrc} alt="avengers" className='prodimg' />
                                                            <i className="fas fa-plus"></i>
                                                        </div>
                                                    </Card>
                                                </div>
                                            </div>

                                        </section>
                                    )}
                                </Dropzone>



                                <div className="ms-Grid-row CarouselRow asd">
                                    <div className="ImageslideMainDiv"
                                        style={{
                                            transform: `translate(-${100 * (this.state.StartIndex / 4)}%)`,
                                            gridTemplateColumns: `repeat(${imgToBeUploaded.length},${100 / 4}%)`,
                                        }}>
                                        {imgToBeUploaded.map((item: any, index: number) => <div className="item ">
                                            <div className="">
                                                <img src={item} className="img-responsive" width={128} height={128} onClick={() => { this.DisplayImage(item) }} />
                                                <i className="far fa-trash-alt" onClick={() => { this.DeleteImage(item) }}></i>
                                            </div>
                                        </div>)}

                                    </div>
                                    <a href="#theCarousel" className="left carousel-control left" onClick={() => { this.setState({ StartIndex: this.state.StartIndex - 4 }) }}>
                                        <i className="fas fa-chevron-left ChevronIcon"></i>
                                    </a>
                                    <a href="#theCarousel" className="right carousel-control right" onClick={() => { this.setState({ StartIndex: this.state.StartIndex + 4 }) }}>
                                        <i className="fas fa-chevron-right ChevronIcon"></i>
                                    </a>
                                </div>
                            </div>

                        }
                    </div>
                </div>

                {/* Right side */}
                < div className="ms-Grid-col ms-lg4 ownerInfo" >

                    <Personinfo PostAdPersonInfo={true} submission={this.submit.bind(this)}/>
                </div >

            </div >
        );
    }
}

function mapStateToProps(state: any) {
    debugger;
    return {
        AttributeItem: state.AttributesReducer.Attributes,
        AdListItem: state.CategoriesReducer.Categories
    };
}

export default connect(mapStateToProps, undefined)(PostAdd);