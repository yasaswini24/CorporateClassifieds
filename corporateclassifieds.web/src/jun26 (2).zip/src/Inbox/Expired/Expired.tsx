import React from 'react';
import { Card, ListGroup, InputGroup, FormControl } from "react-bootstrap";
import { Link } from 'react-router-dom';
import { Route } from 'react-router';
import MessageList from '../MessageList';
import Icon from 'react-icons-kit';
class Expired extends React.Component<any,any>{
    render(){
        return(
            <Card className="Offers" >
                <Card className="Left">
                    <Card.Header>
                        Expired
                    </Card.Header>
                    <Card.Body>
                        <ListGroup >
                            <Link to="/Inbox/Expired/Yamaha">
                                <ListGroup.Item className="OfferItem">
                                    <Card.Img className="OfferImage" variant="top" src="https://capitant.be/wp-content/themes/capitant/assets/images/no-image.png" />
                                    <Card.Body className="OfferDescription">
                                        <Card.Header className="OfferName">Yamaha R15</Card.Header>
                                        <Card.Text className="OfferTime">Timestamp</Card.Text>
                                        <Card.Text className="OfferAmount">Expired</Card.Text>
                                    </Card.Body>
                                </ListGroup.Item>
                            </Link>
                            
                        </ListGroup>
                    </Card.Body>
                </Card>
                <Route exact path="/Inbox/Expired/Yamaha" component={() =>
                    <Card className="Right">
                        <Card.Title>
                            <div>
                                <Card.Img className="Profile" variant="top" src="https://capitant.be/wp-content/themes/capitant/assets/images/no-image.png" />
                                <div className="UserName">{"this.props.item.createdByUser.name"}</div>
                                <div className="MoreOptions"></div>
                            </div>
                        </Card.Title>
                        <Card.Body>
                           <Card.Text>about the report </Card.Text>
                        </Card.Body>
                        
                    </Card>} />
            </Card>
        );
    }
}
export default Expired;