import { async } from "q";

export const FETCH_ADS_SUCCESS = 'FETCH_ADS_SUCCESS';
export const FETCH_ADS_ERROR = 'FETCH_ADS_ERROR';
export const FETCH_ADS_BEGIN = 'FETCH_ADS_BEGIN';
export const FETCH_START_ADS_BEGIN = 'FETCH_START_ADS_BEGIN';
export const POST_AD_ERROR = 'POST_AD_ERROR';
export const POST_AD_SUCCESS = 'POST_AD_SUCCESS';
export const APPLY_FILTERS = 'APPLY_FILTERS';
export const FETCH_ACTIVE_ADS_BEGIN = 'FETCH_ACTIVE_ADS_BEGIN';
export const FETCH_ACTIVE_ADS_SUCCESS = 'FETCH_ACTIVE_ADS_SUCCESS';
export const FETCH_ACTIVE_ADS_ERROR = 'FETCH_ACTIVE_ADS_ERROR';
export const FETCH_HISTORY_ADS_BEGIN = 'FETCH_HISTORY_ADS_BEGIN';
export const FETCH_HISTORY_ADS_SUCCESS = 'FETCH_HISTORY_ADS_SUCCESS';
export const FETCH_HISTORY_ADS_ERROR = 'FETCH_HISTORY_ADS_ERROR';
export const CHANGE_VIEW = 'CHANGE_VIEW';


export const fetchAdsBegin = () =>
  ({
    type: FETCH_ADS_BEGIN
  })

export const fetchStartAdsBegin = () => ({
  type: FETCH_START_ADS_BEGIN
})

export const fetchAdsSuccess = (Ads: any) =>
  ({
    type: FETCH_ADS_SUCCESS,
    payload: { Ads }
  })

export const fetchAdsError = (error: any) =>
  ({
    type: FETCH_ADS_ERROR,
    payload: { error }
  })


export const fetchActiveAdsBegin = () =>
  ({
    type: FETCH_ACTIVE_ADS_BEGIN
  })


export const fetchActiveAdsSuccess = (ActiveAds: any) =>
  ({
    type: FETCH_ACTIVE_ADS_SUCCESS,
    payload: { ActiveAds }
  })

export const fetchActiveAdsError = (error: any) =>
  ({
    type: FETCH_ACTIVE_ADS_ERROR,
    payload: { error }
  })

export const fetchHistoryBegin = () =>
  ({
    type: FETCH_HISTORY_ADS_BEGIN
  })


export const fetchHistorySuccess = (HistoryAds: any) =>
  ({
    type: FETCH_HISTORY_ADS_SUCCESS,
    payload: { HistoryAds }
  })

export const fetchHistoryError = (error: any) =>
  ({
    type: FETCH_HISTORY_ADS_ERROR,
    payload: { error }
  })



export const postAdError = () => ({
  type: POST_AD_ERROR
})


export const postAdSuccess = () => ({
  type: POST_AD_SUCCESS
})


export function applyFilters(selectedList: any) {

}

export const changeview = (ViewID: number) => ({
  type: CHANGE_VIEW,
  payload: { ViewID }
})

//status code will be 1 if active ads need to be fetched and  will be 2 if history need to be fetched 
export function fetchUserAds(userID: number, StatusCode: number, start: number) {
  return async (dispatch: any) => {
    debugger;
    if (StatusCode == 1) {
      dispatch(fetchActiveAdsBegin());
    }
    else {
      dispatch(fetchHistoryBegin());
    }
    try {
      var length = 10
      const url = "https://localhost:44378/api/Ads/GetAdsByUserID/" + userID + "/" + StatusCode + "/" + start + "/" + (start + length);
      const response = await fetch(url);
      debugger;
      const res = await handleErrors(response);
      const json = await res.json();
      if (StatusCode == 1) {
        dispatch(fetchActiveAdsSuccess(json));
      }
      else {
        dispatch(fetchHistorySuccess(json));
      }
    }
    catch (error) {
      if (StatusCode == 1) {
        dispatch(fetchActiveAdsError(error));
      }
      else {
        dispatch(fetchHistoryError(error));
      }
    }
  }
}


export function postAd(AdDetails: any) {
  debugger;
  console.log(JSON.stringify(AdDetails));
  return async (dispatch: any) => {
    try {
      const url = "https://localhost:44378/api/Ads";
      const response = await fetch(url, {
        method: 'post',
        headers: new Headers({ 'content-type': 'application/json' }),
        body: JSON.stringify(AdDetails)
      });
      const res = await handleErrors(response);
      dispatch(postAdSuccess());
    }
    catch (error) {
      return dispatch(postAdError());
    }
  }
}


export function fetchAds(start: number) {
  return async (dispatch: any) => {
    debugger;
    if (start == 0) {
      dispatch(fetchStartAdsBegin());
    }
    else{
      dispatch(fetchAdsBegin());
    }
    try {
      var length = 10
      const response = await fetch("https://localhost:44378/api/Ads/" + start + "/" + (start + length));
      console.log(response);
      const res = await handleErrors(response);
      const json = await res.json();
      debugger;
      dispatch(fetchAdsSuccess(json));
    }
    catch (error) {
      return dispatch(fetchAdsError(error));
    }
  };
}

// Handle HTTP errors since fetch won't.
function handleErrors(response: any) {
  if (!response.ok) {
    throw Error(response.statusText);
  }
  return response;
}




