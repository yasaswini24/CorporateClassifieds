
const initialstate={
    Categories:[],
    CategoriesError:false
}

export default function CategoriesReducer(state=initialstate,action:any)
{
    switch(action.type)
    {
        case 'CategoriesFetchSuccess':
            return{
                ...state,
                Categories:action.payload.Categories
            }
        case 'AttributeFetchError':
            return{
                ...state,
                CategoriesError:true
            }
        default:
            return{
                ...state
            }
    }
}