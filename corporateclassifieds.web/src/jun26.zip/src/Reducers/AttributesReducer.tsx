
const initialstate={
    Attributes:[],
    AttributesError:false
}

export default function AttributesReducer(state=initialstate,action:any)
{
    switch(action.type)
    {
        case 'AttributeFetchSuccess':
            debugger;
            return{
                ...state,
                Attributes:action.payload.Attributes
            }
        case 'AttributeFetchError':
            return{
                ...state,
                AttributesError:true
            }
        default:
            return{
                ...state
            }
    }
}