import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './App';
import * as serviceWorker from './serviceWorker';
import { Provider } from 'react-redux';
import { createStore } from 'redux';
import { ic_location_city } from 'react-icons-kit/md/ic_location_city';
var initialstate = {
    // navlist: [{ name: 'Classifieds', src: require('./icons/bike/Bike.png'),path:'/Classifieds'}, { name: 'My Classifieds', src: require('./icons/books/book.png') },
    // { name: 'Inbox', src: require('./icons/phone/smartphone.png') }],
    AdList: [
        { src: require('./r15.jpg'), name: 'Yamaha R15', icons: ic_location_city, description: 'hello this is me Bhaskar! this home is too big.this is actually where ghosts reside. the best place to spend ur last few days.', price: '10,00,000', postedBy: 'Bhaskar gali', postedOn: '12 June,1998', expires: '16 May, 2028', offersCount: '3', commentCount: '20' },
        { src: require('./r15.jpg'), name: 'Yamaha R15', icons: ic_location_city, description: 'hello this is me Bhaskar! this home is too big.this is actually where ghosts reside. the best place to spend ur last few days.', price: '10,00,000', postedBy: 'Bhaskar gali', postedOn: '12 June,1998', expires: '16 May, 2028', offersCount: '3', commentCount: '20' },
        { src: require('./r15.jpg'), name: 'Yamaha R15', icons: ic_location_city, description: 'hello this is me Bhaskar! this home is too big.this is actually where ghosts reside. the best place to spend ur last few days.', price: '10,00,000', postedBy: 'Bhaskar gali', postedOn: '12 June,1998', expires: '16 May, 2028', offersCount: '3', commentCount: '20' },
        { src: require('./r15.jpg'), name: 'Yamaha R15', icons: ic_location_city, description: 'hello this is me Bhaskar! this home is too big.this is actually where ghosts reside. the best place to spend ur last few days.', price: '10,00,000', postedBy: 'Bhaskar gali', postedOn: '12 June,1998', expires: '16 May, 2028', offersCount: '3', commentCount: '20' },
        { src: require('./r15.jpg'), name: 'Yamaha R15', icons: ic_location_city, description: 'hello this is me Bhaskar! this home is too big.this is actually where ghosts reside. the best place to spend ur last few days.', price: '10,00,000', postedBy: 'Bhaskar gali', postedOn: '12 June,1998', expires: '16 May, 2028', offersCount: '3', commentCount: '20' },
        { src: require('./r15.jpg'), name: 'Yamaha R15', icons: ic_location_city, description: 'hello this is me Bhaskar! this home is too big.this is actually where ghosts reside. the best place to spend ur last few days.', price: '10,00,000', postedBy: 'Bhaskar gali', postedOn: '12 June,1998', expires: '16 May, 2028', offersCount: '3', commentCount: '20' },
        { src: require('./r15.jpg'), name: 'Yamaha R15', icons: ic_location_city, description: 'hello this is me Bhaskar! this home is too big.this is actually where ghosts reside. the best place to spend ur last few days.', price: '10,00,000', postedBy: 'Bhaskar gali', postedOn: '12 June,1998', expires: '16 May, 2028', offersCount: '3', commentCount: '20' },
        { src: require('./r15.jpg'), name: 'Yamaha R15', icons: ic_location_city, description: 'hello this is me Bhaskar! this home is too big.this is actually where ghosts reside. the best place to spend ur last few days.', price: '10,00,000', postedBy: 'Bhaskar gali', postedOn: '12 June,1998', expires: '16 May, 2028', offersCount: '3', commentCount: '20' },
        { src: require('./r15.jpg'), name: 'Yamaha R15', icons: ic_location_city, description: 'hello this is me Bhaskar! this home is too big.this is actually where ghosts reside. the best place to spend ur last few days.', price: '10,00,000', postedBy: 'Bhaskar gali', postedOn: '12 June,1998', expires: '16 May, 2028', offersCount: '3', commentCount: '20' },
        { src: require('./r15.jpg'), name: 'Yamaha R15', icons: ic_location_city, description: 'hello this is me Bhaskar! this home is too big.this is actually where ghosts reside. the best place to spend ur last few days.', price: '10,00,000', postedBy: 'Bhaskar gali', postedOn: '12 June,1998', expires: '16 May, 2028', offersCount: '3', commentCount: '20' },
        { src: require('./r15.jpg'), name: 'Yamaha R15', icons: ic_location_city, description: 'hello this is me Bhaskar! this home is too big.this is actually where ghosts reside. the best place to spend ur last few days.', price: '10,00,000', postedBy: 'Bhaskar gali', postedOn: '12 June,1998', expires: '16 May, 2028', offersCount: '3', commentCount: '20' },
        { src: require('./r15.jpg'), name: 'Yamaha R15', icons: ic_location_city, description: 'hello this is me Bhaskar! this home is too big.this is actually where ghosts reside. the best place to spend ur last few days.', price: '10,00,000', postedBy: 'Bhaskar gali', postedOn: '12 June,1998', expires: '16 May, 2028', offersCount: '3', commentCount: '20' },
        { src: require('./r15.jpg'), name: 'Yamaha R15', icons: ic_location_city, description: 'hello this is me Bhaskar! this home is too big.this is actually where ghosts reside. the best place to spend ur last few days.', price: '10,00,000', postedBy: 'Bhaskar gali', postedOn: '12 June,1998', expires: '16 May, 2028', offersCount: '3', commentCount: '20' },
        { src: require('./r15.jpg'), name: 'Yamaha R15', icons: ic_location_city, description: 'hello this is me Bhaskar! this home is too big.this is actually where ghosts reside. the best place to spend ur last few days.', price: '10,00,000', postedBy: 'Bhaskar gali', postedOn: '12 June,1998', expires: '16 May, 2028', offersCount: '3', commentCount: '20' },
        { src: require('./r15.jpg'), name: 'Yamaha R15', icons: ic_location_city, description: 'hello this is me Bhaskar! this home is too big.this is actually where ghosts reside. the best place to spend ur last few days.', price: '10,00,000', postedBy: 'Bhaskar gali', postedOn: '12 June,1998', expires: '16 May, 2028', offersCount: '3', commentCount: '20' },
        { src: require('./r15.jpg'), name: 'Yamaha R15', icons: ic_location_city, description: 'hello this is me Bhaskar! this home is too big.this is actually where ghosts reside. the best place to spend ur last few days.', price: '10,00,000', postedBy: 'Bhaskar gali', postedOn: '12 June,1998', expires: '16 May, 2028', offersCount: '3', commentCount: '20' },
        { src: require('./r15.jpg'), name: 'Yamaha R15', icons: ic_location_city, description: 'hello this is me Bhaskar! this home is too big.this is actually where ghosts reside. the best place to spend ur last few days.', price: '10,00,000', postedBy: 'Bhaskar gali', postedOn: '12 June,1998', expires: '16 May, 2028', offersCount: '3', commentCount: '20' },
        { src: require('./r15.jpg'), name: 'Yamaha R15', icons: ic_location_city, description: 'hello this is me Bhaskar! this home is too big.this is actually where ghosts reside. the best place to spend ur last few days.', price: '10,00,000', postedBy: 'Bhaskar gali', postedOn: '12 June,1998', expires: '16 May, 2028', offersCount: '3', commentCount: '20' }
    ]


,


    user:{name: 'bhaskar'},

    LinkDescription:{
        ActiveClassifieds:{
            header:"ActiveClassifieds",Desc:"here you can manage the way you capture things",ButtonName:"Add Category",IsActive:false
        },
        History:{
            header:"History",Desc:"here you can manage the way you capture things",ButtonName:"Add Category",IsActive:false
        }

    },

    categoryList: [{ name: "Property" }, { name: "Vehicle" }, { name: "Books" }, { name: "Electronics" }],
    

}

function reducer(state = initialstate) {
    return state;
}
const store = createStore(reducer);

ReactDOM.render(<Provider store={store}><App /></Provider>, document.getElementById('root'));

serviceWorker.unregister();
