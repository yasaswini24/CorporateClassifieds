import React,{Component} from 'react';
import {Link,Route,BrowserRouter as Router } from "react-router-dom";
import 'office-ui-fabric-react/dist/css/fabric.css';
import { Icon } from 'office-ui-fabric-react/lib/Icon';
import { initializeIcons } from '@uifabric/icons';
import { connect } from "react-redux";
import './Classifieds.sass';
import SaleRent from "./SaleRent/SaleRent";
import Required from "./Required/Required";




initializeIcons();
class Classifieds extends Component<any,any>
{
    render()
    {
        return(
            <Router>
            <Link to="Classifieds">
                <div className="Classifieds">
                    <nav className="top-menu">
                            <ul className="nav">
                        
                            <li className="nav-item" >
                                <Link to="SaleRent" className="nav-link active">
                                For Sale/Rent
                                </Link>
                            </li>
                        
                            <li className="nav-item">
                                <Link to="Required" className="nav-link" >
                                    Required
                                </Link>
                            </li>
                        
                            </ul>
                    </nav>
                    <div>
                        <Route exact path="/" component={SaleRent}/> 
                        <Route  path="/Classifieds" component={SaleRent}/> 
                        <Route  path="/SaleRent" component={SaleRent}/>
                        <Route  path="/Required" component={Required}/>
                    </div>
            </div>
           </Link>
           </Router>
        );
    }
}
function mapStateToProps(state:any)
{
    return{
    user:state.user
    }
}
export default connect(mapStateToProps)(Classifieds);













