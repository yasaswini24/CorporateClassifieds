import React,{Component} from 'react';
import {Link, BrowserRouter as Router,Route } from "react-router-dom";
import 'office-ui-fabric-react/dist/css/fabric.css';
import { Icon } from 'office-ui-fabric-react/lib/Icon';
import { initializeIcons } from '@uifabric/icons';
import { connect } from "react-redux";
import './../SaleRent/SaleRent.sass';
import ListView from "./ListView/ListView";
import GridView from "./Gridview";


initializeIcons();
class SaleRent extends Component<any,any>
{
    render()
    {
        return(
            <div className="SaleRent">
                <Router>
                <main className="content-wrapper">
                    <div className="header">
                        <h1>For Sale/Rent</h1>
                        <p>Here you can manage categories.</p>
                    </div>
                    
                    <div>
                        <Route exact path="/" component={ListView}/>
                        <Route exact path="/Classifieds" component={ListView}/>
                        <Route exact path="/SaleRent" component={ListView}/>
                        <Route exact path="/ListView" component={ListView}/>
                        <Route exact path="/GridView" component={GridView}/>
                    </div>
                    
                  
                </main>
                </Router>
        </div>
           
        );
    }
}
function mapStateToProps(state:any)
{
    return{
    user:state.user
    }
}
export default connect(mapStateToProps)(SaleRent);













