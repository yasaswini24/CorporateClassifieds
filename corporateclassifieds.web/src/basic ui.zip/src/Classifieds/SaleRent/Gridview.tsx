import React from 'react'
import { Component } from 'react'
import { connect } from 'react-redux';
import 'office-ui-fabric-react/dist/css/fabric.css';
import Icon from 'react-icons-kit';
import DropDownBar from './ListView/DropDownBar';
import './Gridview.css';

//import '../cssfiles/ListView.css';
import { ic_location_city } from 'react-icons-kit/md/ic_location_city';
import { isTSNumberKeyword } from '@babel/types';
import { PeoplePickerItemSuggestion } from 'office-ui-fabric-react';
class Gridview extends Component<any, any>{
    render() {
        return (
            <div className="Gridview">
                <div className="ms-Grid List ItemDropDown" dir="ltr">
                    <div className="ms-Grid-row">
                        <DropDownBar />
                    </div>
                </div>
                {this.props.AdListItem.map((item: any) =>
                    <div className='card text-center'>
                        <div className="card-header CardHeader">
                            <img width={32} height={32} className="img-circle" src={item.src} alt="Generic placeholder" />
                            <p className='profname'>{item.postedBy}</p>
                            <p className='text-muted'>{item.postedOn}</p>
                        </div>
                        <div className='overflow'>
                            <img src={item.src} alt="avengers" className='GridProductimage' />
                            <div className="container-fluid">
                                <div className="row prodtag" >
                                     <div className="col-md-4 prodname">
                                        <div className="icon">
                                            <Icon className="CategoryIcon" size={25} icon={item.icons} />
                                        </div>
                                        <p className="card-title">{item.name}</p>
                                    </div>
                                    <div className="col-md-4 prodprice">
                                        <p className="card-price">  <span>&#x20b9;</span> {item.price}</p>
                                    </div>
                                </div>
                            </div>
                            
                        </div>
                        <div className="card-body">
                            <div className="desc">
                                <p className="card-text text-secondary">{item.description}</p>
                            </div>
                        </div>
                        <div className="card-footer CardFooter">
                            <Icon className="CategoryIcon" size={25} icon={item.icons} />
                            <Icon className="CategoryIcon" size={25} icon={item.icons} />

                        </div>
                    </div>
                )}
            </div>

        );
    }
}
function mapStateToProps(state: any) {
    return {
        AdListItem: state.AdList
    };
}

export default connect(mapStateToProps, undefined)(Gridview);