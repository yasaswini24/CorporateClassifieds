import React from 'react'
import { Component } from 'react'
import { connect } from 'react-redux';
import 'office-ui-fabric-react/dist/css/fabric.css';
import Icon from 'react-icons-kit';
import DropDownBar from './DropDownBar';
//import '../cssfiles/ListView.css';
// import { ic_location_city } from 'react-icons-kit/md/ic_location_city';
// import './../../App.css';
import "./ListView.sass";




import { isTSNumberKeyword } from '@babel/types';
class ListView extends Component<any, any>{
  render() {
    return (
      <div className="ListItemGrid">
        <div className="ms-Grid List ItemDropDown" dir="ltr">
          <div className="ms-Grid-row">
            <DropDownBar />
          </div></div>
        <div className="ms-Grid List ListItemHeader" dir="ltr">
          <div className="ms-Grid-row">
            <div className="ms-Grid-col ms-sm5">

              <div className="ms-Grid-col ms-sm3  block">
                ITEM OR SELL
                    </div>

              <div className="ms-Grid-col ms-sm10">
                <div className="ms-Grid-row">

                </div>
                <div className="ms-Grid-row block3">

                </div>
              </div>

            </div>

            <div className="ms-Grid-col ms-sm7">

              <div className="ms-Grid-col ms-sm2 block">PRICE</div>

              <div className="ms-Grid-col ms-sm3 block">
                <div className="ms-Grid-row name">Name</div>
              </div>

              <div className="ms-Grid-col ms-sm3 block">EXPIRES ON</div>

              <div className="ms-Grid-col ms-sm2  block">OFFER COUNT</div>

              <div className="ms-Grid-col ms-sm2 block ">COMMENT COUNT</div>

            </div>


          </div>

        </div>

        {this.props.AdListItem.map((item: any) =>
          <div className="ms-Grid List ListItem" dir="ltr">
            <div className="ms-Grid-row">
              <div className="ms-Grid-col ms-sm5">
                <div className="ms-Grid-col ms-sm2  imageOfAdInList">
                  <img className="ListProductImage" src={item.src} />
                </div>
                <div className="ms-Grid-col ms-sm8 block PostDetails">
                  <div className="ms-Grid-row">
                    <Icon className="CategoryIcon" size={25} icon={item.icons} />
                    {item.name}
                  </div>
                  <div className="ms-Grid-row description">
                    {item.description}
                  </div>
                </div>
              </div>
              <div className="ms-Grid-col ms-sm7">
                <div className="ms-Grid-col ms-sm2 block">{item.price}</div>
                <div className="ms-Grid-col ms-sm3 block">
                  <div className="ms-Grid-row name">{item.postedBy}</div>
                  <div className="ms-Grid-row PostedOn">{item.postedOn}</div>
                </div>
                <div className="ms-Grid-col ms-sm3 block">{item.expires}</div>
                <div className="ms-Grid-col ms-sm2  block">{item.offersCount}</div>
                <div className="ms-Grid-col ms-sm2 block ">{item.commentCount}</div>
              </div>
            </div></div>
        )}

      </div>


    );
  }
}
function mapStateToProps(state: any) {
  return {
    AdListItem: state.AdList
  };
}

export default connect(mapStateToProps, undefined)(ListView);