// export function IsError(bool)
// {
//     return 
//     {
//         type:'ADS_ERROR',
//         hasError:bool
//     };
// }


// export function (bool)
// {
//     return 
//     {
//         type:'ADS_ERROR',
//         hasError:bool
//     };
// }

// export function IsError(bool)
// {
//     return 
//     {
//         type:'ADS_ERROR',
//         hasError:bool
//     };
// }