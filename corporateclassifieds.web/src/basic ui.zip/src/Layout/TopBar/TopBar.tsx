import React,{Component} from 'react';
import {Link } from "react-router-dom";
import 'office-ui-fabric-react/dist/css/fabric.css';
import { Icon } from 'office-ui-fabric-react/lib/Icon';
import { initializeIcons } from '@uifabric/icons';
import './TopBar.sass';
import { connect } from "react-redux";

initializeIcons();
class TopBar extends Component<any,any>
{
    render()
    {
        return(
            
              <header className="TopBar">
                <Link to="/">
                    <div className="Logo">
                        <Icon iconName="ShoppingCart"/>
                    </div>

                    <div className="Title">
                        Classifieds
                    </div>              
                </Link>
           
                <div className="UserOptions">
                    <div className="username">
                        { this.props.user.name }
                    </div>
                    <Link to="Profile">
                        <img
                            src={this.props.user.image}
                            alt={this.props.user.name }/>
                    </Link>
                </div>    
                </header> 
                
           
        );
    }
}
function mapStateToProps(state:any)
{
    return{
    user:state.user
    }
}
export default connect(mapStateToProps)(TopBar);