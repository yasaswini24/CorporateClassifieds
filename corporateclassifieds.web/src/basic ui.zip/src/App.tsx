import React from 'react';
import  TopBar  from "./Layout/TopBar/TopBar";
import './App.sass';
import { Route,BrowserRouter as Router, Switch} from "react-router-dom";
import  SideMenu  from "./Layout/SideMenu/SideMenu";
import Classifieds from "./Classifieds/Classifieds";
import MyClassifieds from "./MyClassifeds/MyClassifieds";
import Admin from './Admin/Admin';

const App: React.FC = () => {
  return (
    <div className="App">
      <Router>
      
        <TopBar/>
      
        <div className="container-fluid">
          <div className="row">

            {/* Sidebar  */}
            <SideMenu/>

             Main Router Content
            <div className="main-content">
              
              <Route exact  path="/" component={Classifieds}/>
              <Route path="/Classifieds" component={Classifieds}/>
              <Route path="/MyClassifieds" component={MyClassifieds}/>
              <Route path="/Admin" component={Admin}/>
              {/* <Route path="Profile" component={ViewProfile}/>
                  <Route path="Inbox" component={Inbox}/>
             */}
              
            </div>
            
          </div>
        </div>

        
       
        
      
      </Router>
    </div>
  );
}

export default App;
