import React,{Component} from 'react';
import {Link,Route,BrowserRouter as Router } from "react-router-dom";
import 'office-ui-fabric-react/dist/css/fabric.css';
import { Icon } from 'office-ui-fabric-react/lib/Icon';
import { initializeIcons } from '@uifabric/icons';
import { connect } from "react-redux";
import History from './History/History';
import ActiveClassifieds from "./ActiveClassifieds/ActiveClassifieds";
import  "./MyClassifieds.sass";


initializeIcons();
class MyClassifieds extends Component<any,any>
{
    render()
    {
        return(
            <Router>
            <Link to="MyClassifieds">
                <div className="MyClassifieds">
                    <nav className="top-menu">
                            <ul className="nav">
                        
                            <li className="nav-item" >
                                <Link to="ActiveClassifieds" className="nav-link active">
                                Active Classifieds
                                </Link>
                            </li>
                        
                            <li className="nav-item">
                                <Link to="History" className="nav-link" >
                                    History
                                </Link>
                            </li>
                        
                            </ul>
                    </nav>
                    <div>
                        <Route exact path="/MyClassifieds" component={ActiveClassifieds}/>
                        <Route exact path="/ActiveClassifieds" component={ActiveClassifieds}/>
                        <Route exact path="/History" component={History}/>
                    </div>
            </div>
           </Link>
           </Router>
        );
    }
}
function mapStateToProps(state:any)
{
    return{
    user:state.user
    }
}
export default connect(mapStateToProps)(MyClassifieds);













