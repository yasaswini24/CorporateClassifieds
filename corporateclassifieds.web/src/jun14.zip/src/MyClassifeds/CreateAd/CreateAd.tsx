import React from 'react';
import './CreateAd.sass';





// interface IState {
//     Type: string,
//     Category: { id: number },
//     Price: number,
//     Name: string,
//     Description: string,
//     CreatedByUser: { id: number },
//     ModifiedByUser: { id: number },
//     Status: { id: number },
//     Expiry: number
// }



export class CreateAd extends React.Component<any, any> {

    constructor(props: any) {
        super(props);
        this.state = { Type: "", CategoryDetails: { id: 1 }, Price: 0, Name: "", Description: "", CreatedByUser: { id: 1 }, ModifiedByUser: { id: 1 }, Status: { id: 1 }, Expiry: 0 ,Images:[]};
    }

    submit() {

        let Ad = this.state;
        this.setState({ Type: "", CategoryDetails: { id: 1 }, Price: 0, Name: "", Description: "", CreatedByUser: { id: 1 }, ModifiedByUser: { id: 1 }, Status: { id: 1 }, Expiry: 0 });
        console.log(JSON.stringify(Ad));
        const url = "https://localhost:44378/api/Ads";
        fetch(url, {
            method: 'post',
            headers: new Headers({ 'content-type': 'application/json' }),
            body: JSON.stringify(Ad)
        }).then(function (response) {
            console.log("success");
        });



    }
    change(e: any) {
        this.setState(
            {
                [e.target.name]: e.target.value

            }
        );
    }

    getCategoryID(e: any) {
        var CategoryID:number=0;

        const url = "https://localhost:44378/api/Category/" + e.target.value;
        fetch(url, {
            method: 'GET',
            headers: new Headers({ 'content-type': 'application/json' })
        }).then(async function (response) {
            // console.log(await response.json());
            CategoryID = await response.json();
        });
        //this.setState({ Category: { id: CategoryID } });

    }

    ImagesUpload(e:any)
    {

        this.setState({Images:[...this.state.Images,e.target.value]});
    }



    render() {
        return (
            <div className="container">
                <table className="table">

                    <tbody>
                        <tr>
                            <td><label className="ms-Label">Ad Type</label></td>
                        </tr>
                        <tr className="Field">
                            <div className="ms-Dropdown">

                                <select className="ms-Dropdown-select" name="Type" onChange={this.change.bind(this)}>

                                    <option>For Sale</option>
                                    <option>For Rent</option>
                                    <option>Required</option>
                                </select>
                            </div>
                        </tr>
                        <tr>
                            <td><label className="ms-Label">Category</label></td>
                        </tr>
                        <tr className="Field">
                            <div className="ms-Dropdown">

                                <select className="ms-Dropdown-select" name="CategoryDetails" onChange={this.getCategoryID.bind(this)}>

                                    <option>Property</option>
                                    <option>Electronics</option>

                                </select>
                            </div>
                        </tr>
                        <tr>
                            <td><label>Price</label></td>
                        </tr>
                        <tr className="Field">

                            <input key="Price" type="textfield" name="Price" value={this.state.Price} onChange={this.change.bind(this)} />


                        </tr>
                        <tr>
                            <td> <label>Ad Name</label></td>
                        </tr>
                        <tr className="Field">

                            <input key="Name" type="textfield" name="Name" value={this.state.Name} onChange={this.change.bind(this)} />

                        </tr>
                        <tr>
                            <td><label>Description</label></td>
                        </tr>
                        <tr className="Field">
                            <input key="Description" type="textarea" name="Description" value={this.state.Description} onChange={this.change.bind(this)} />
                        </tr>
                        <tr>
                            <td><label>Expiry</label></td>
                        </tr>
                        <tr className="Field">
                            <input key="Expiry" type="number" name="Expiry" value={this.state.Expiry} onChange={this.change.bind(this)} />
                        </tr>
                    </tbody>
                </table>
                <input type="file" multiple name="Images" onChange={this.ImagesUpload.bind(this)}/>
                <input className="button" type="button" value="Add" onClick={this.submit.bind(this)} />
            </div>
        );
    }
}