import {combineReducers} from 'redux';
import AdReducer  from "./AdReducer";
import ImageReducer from "./ImageReducer";
export default combineReducers(
    {
        AdReducer,
        ImageReducer
    }
);