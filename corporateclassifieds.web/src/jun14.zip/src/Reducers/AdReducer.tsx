import { FETCH_ADS_BEGIN, FETCH_ADS_SUCCESS, FETCH_ADS_ERROR } from "../Actions/AdActions";

const intialstate = {
    Ads: [],
    error: null,
    loading: true
};

export default function AdReducer(state = intialstate, action: any) {
    switch (action.type) {
        case FETCH_ADS_BEGIN: console.log("begin");
            return {
                ...state,
                loading: true,
                error: false,

            }

        case FETCH_ADS_SUCCESS: console.log("success")
            return {
                ...state,
                loading: false,
                Ads: action.payload.Ads
            }

        case FETCH_ADS_ERROR: console.log("error")
            return {
                ...state,
                loading: false,
                error: action.payload.error,
                Ads: []
            }

        default:
            return state;
    }
}