export const FETCH_ADS_SUCCESS = 'FETCH_ADS_SUCCESS';
export const FETCH_ADS_ERROR = 'FETCH_ADS_ERROR';
export const FETCH_ADS_BEGIN = 'FETCH_ADS_BEGIN';
export const CHANGE_IMAGE_STATUS = 'CHANGE_IMAGE_STATUS';

export const fetchAdsBegin = () =>
  ({
    type: FETCH_ADS_BEGIN
  })


export const fetchAdsSuccess = (Ads: any) =>
  ({
    type: FETCH_ADS_SUCCESS,
    payload: { Ads }
  })

export const fetchAdsError = (error: any) =>
  ({
    type: FETCH_ADS_ERROR,
    payload: { error }
  })

export const changeImageFetchStatus = () =>
  ({
    type: CHANGE_IMAGE_STATUS
  })


export function fetchAds() {
  return async (dispatch: any) => {
    dispatch(fetchAdsBegin());
    try {
      const response = await fetch("https://localhost:44378/api/Ads");
      console.log(response);
      const res = await handleErrors(response);
      const json = await res.json();
      dispatch(fetchAdsSuccess(json));
    }
    catch (error) {
      return dispatch(fetchAdsError(error));
    }
  };
}

// Handle HTTP errors since fetch won't.
function handleErrors(response: any) {
  if (!response.ok) {
    throw Error(response.statusText);
  }
  return response;
}




