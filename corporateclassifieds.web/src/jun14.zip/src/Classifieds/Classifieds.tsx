import React, { Component } from 'react';
import { Link, Route, BrowserRouter as Router, Redirect } from "react-router-dom";
import 'office-ui-fabric-react/dist/css/fabric.css';
import { initializeIcons } from '@uifabric/icons';
import { connect } from "react-redux";
import './Classifieds.sass';
import SaleRent from "./SaleRent/SaleRent";
import Required from "./Required/Required";




initializeIcons();
class Classifieds extends Component<any, any>
{
    render() {
        return (
            <div className="Classifieds">
                <nav className="top-menu">
                    <ul className="nav">

                        <li className="nav-item" >
                            <Link to="/Classifieds/SaleRent" className="nav-link active">
                                For Sale/Rent
                                </Link>
                        </li>

                        <li className="nav-item">
                            <Link to="/Classifieds/Required" className="nav-link" >
                                Required
                                </Link>
                        </li>

                    </ul>
                </nav>
                <div>
                   
                
                    <Route exact path="/Classifieds" component={SaleRent} />
                    <Route path="/Classifieds/SaleRent" component={SaleRent} />
                    <Route path="/Classifieds/Required" component={Required} />
                    <Redirect to='/Classifieds'/>
                </div>
            </div>

        );
    }
}
function mapStateToProps(state: any) {
    return {
        user: state.user
    }
}
export default connect(mapStateToProps)(Classifieds);













