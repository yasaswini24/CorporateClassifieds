import React from 'react'
import { Component } from 'react'
import { connect } from 'react-redux';
import DropDownBar from '../ListView/DropDownBar';
import { AdCard } from './AdCard';
import './GridView.sass';

class Gridview extends Component<any, any>{
    render() {
        return (
            <div className="Gridview">
                <div className="ms-Grid List ItemDropDown" dir="ltr">
                    <div className="ms-Grid-row">
                        <DropDownBar />
                    </div>
                </div>
                {this.props.AdListItem.map((item: any) =>
                    <AdCard key={item.id} item={item} />
                )}
            </div>

        );
    }
}
function mapStateToProps(state: any) {
    
    return {
        error: state.AdReducer.error,
        loading: state.AdReducer.loading,
        AdListItem: state.AdReducer.Ads
    };
}

export default connect(mapStateToProps, undefined)(Gridview);