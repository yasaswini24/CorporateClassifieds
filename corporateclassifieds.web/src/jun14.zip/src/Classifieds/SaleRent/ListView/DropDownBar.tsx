import React, { Component } from 'react';
import { Link } from 'react-router-dom';
import 'office-ui-fabric-react/dist/css/fabric.css';
import { Dropdown } from 'office-ui-fabric-react/lib/Dropdown';
import { initializeIcons } from 'office-ui-fabric-react/lib/Icons';
import { SearchBox } from 'office-ui-fabric-react/lib/SearchBox';
import { DefaultButton} from 'office-ui-fabric-react';
import { undo } from 'react-icons-kit/fa/undo'
import Icon from 'react-icons-kit';
import { list2 } from 'react-icons-kit/icomoon/list2'
import { ic_apps } from 'react-icons-kit/md/ic_apps'
initializeIcons();


export interface IDropdownControlledMultiExampleState {
  selectedItems: string[];
}

export default class DropDownBar extends Component<any, IDropdownControlledMultiExampleState>
{
  public state: IDropdownControlledMultiExampleState = {
    selectedItems: []
  };

  render() {
    return (
      <div className="ms-Grid DropDownBar" dir="ltr">
        <div className="ms-Grid-col ms-sm7 DropDownFilters">
          <div className="ms-Grid-col ms-sm2 AdTypeDropDown">
            <Dropdown
              className="testing"
              placeholder="Ad Type"
              multiSelect
              options={[
                { key: 'sale', text: 'For Sale' },
                { key: 'rent', text: 'For Rent' }
              ]}


            />
          </div>
          <div className="ms-Grid-col ms-sm3 CategoryDropDown">
            <Dropdown
              placeholder="Category"

              options={[
                { key: 'A', text: 'Option a', data: { icon: 'Memo' } },
                { key: 'A', text: 'Option a', data: { icon: 'Memo' } },
                { key: 'A', text: 'Option a', data: { icon: 'Print' } },
                { key: 'A', text: 'Option a', data: { icon: 'Memo' } },
                { key: 'A', text: 'Option a', data: { icon: 'Memo' } }
              ]}
            />
          </div>
          <div className="ms-Grid-col ms-sm3 PostedDropDown">
            <Dropdown
              placeholder="Posted"
              multiSelect
              options={[
                { key: 'vehicle', text: 'Vehicle' },
                { key: 'property', text: 'Property' }
              ]}
            />
          </div>
          <div className="ms-Grid-col ms-sm4 LocationDropDown">
            <Dropdown
              placeholder="Location"
              multiSelect
              options={[
                { key: 'vehicle', text: 'Vehicle' },
                { key: 'property', text: 'Property' }
              ]}
            />
          </div>

        </div>
        <div className="ms-Grid-col ms-sm5 Search">
          <div className="ms-Grid-col ms-sm8 SearchBar">
            <SearchBox />
          </div>
          <div className="ms-Grid-col ms-sm2 Reset">
            <DefaultButton className="ResetButton">
              <Icon size={20} icon={undo} />
              <label>Reset</label>
            </DefaultButton>
          </div>

          <Link to="/Classifieds/SaleRent/GridView">
            <div className="ms-Grid-col ms-sm1 GridViewOption">
              <DefaultButton>
                <Icon size={30} icon={ic_apps} />
              </DefaultButton>
            </div>
          </Link>


          <Link to="/Classifieds/SaleRent/ListView">
            <div className="ms-Grid-col ms-sm1 ListViewOption" >
              <DefaultButton>
                <Icon size={20} icon={list2} />
              </DefaultButton>
            </div>
          </Link>

        </div></div>


    );

  }


}
