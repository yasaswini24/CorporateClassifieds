import React, { Component } from "react";
import { connect } from "react-redux";
// import { Link } from "react-router-dom";
import "./Inbox.sass";
import { Card, ListGroup } from "react-bootstrap";
import Icon from "react-icons-kit";
import { ic_location_city } from 'react-icons-kit/md/ic_location_city';
class Inbox extends Component {
    render() {
        return (
            <div className="Inbox">
                <nav className="top-menu">
                    <ul className="nav">
                        <li className="nav-item" >
                            <a href="Inbox" className="nav-link active">
                                Inbox
                            </a>
                        </li>
                    </ul>
                </nav>
                <main className="content-wrapper">
                    <div className="header">
                        <h1>Inbox</h1>
                        <p>Here you can manage Ads and Offers.</p>
                    </div>

                    <div>

                    </div>
                </main>

                <div>
                    <Card>
                        <Card.Header>
                            Pending Tasks
                    </Card.Header>
                        <ListGroup defaultActiveKey="#Offers">
                            <ListGroup.Item action href="#Offers">
                                <Icon size={25} icon={ic_location_city} />
                                <span>Offers(0)</span>
                            </ListGroup.Item>
                            <ListGroup.Item action href="#Reports">
                                <Icon size={25} icon={ic_location_city} />
                                <span>Reports(0)</span>
                            </ListGroup.Item>
                            <ListGroup.Item action href="#Ad Expired">
                                <Icon size={25} icon={ic_location_city} />
                                <span>Ad Expired(0)</span>
                            </ListGroup.Item>
                            <ListGroup.Item action href="#Deleted">
                                <Icon size={25} icon={ic_location_city} />
                                <span>Deleted(0)</span>
                            </ListGroup.Item>
                        </ListGroup>
                    </Card>

                </div>
            </div>

        );
    }
}

export default connect(undefined)(Inbox);